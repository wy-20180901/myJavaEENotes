$:.unshift(File.join(File.dirname(__FILE__), '..', 'lib'))

require 'rubygems'
require 'mongo'
require 'test/unit'
require 'shoulda'
require 'inventory'
