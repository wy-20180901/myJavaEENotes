# Inventory

Sample inventory management in MongoDB.

Check out the test suite to see how it works:
  rake test
