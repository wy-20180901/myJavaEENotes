doc =
{  _id: ObjectId("6a5b1476238d3b4dd5000048"),
   slug: "gardening-tools",
   ancestors: [{ name: "Home",
                 _id:  ObjectId("8b87fb1476238d3b4dd50003"),
                 slug: "home"
                },

                { name: "Outdoors",
                  _id:  ObjectId("9a9fb1476238d3b4dd500001"),
                  slug: "outdoors"
                }
   ],

   parent_id: ObjectId("9a9fb1476238d3b4dd500001"),

   name: "Gardening Tools",
   description: "Gardening gadgets galore!",
}
