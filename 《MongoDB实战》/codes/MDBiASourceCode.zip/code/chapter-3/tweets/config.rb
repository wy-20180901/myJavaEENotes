# <start id="config" />  
DATABASE_NAME   = "twitter-archive"
COLLECTION_NAME = "tweets"
TAGS = ["mongodb", "nosql"]
# <end id="config" />
