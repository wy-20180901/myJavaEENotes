package com.fruitsalesplatform.entity;

public class MiddleTab {
    private String middleId;
    private String contractId;
    private String fruitId;
	private int number;
	public String getMiddleId() {
		return middleId;
	}
	public void setMiddleId(String middleId) {
		this.middleId = middleId;
	}
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	public String getFruitId() {
		return fruitId;
	}
	public void setFruitId(String fruitId) {
		this.fruitId = fruitId;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	
}
