package cn.com.mvc.model;

public class UserAndProductQryModel {
	private User user;
	private Fruits userFruits;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Fruits getUserFruits() {
		return userFruits;
	}
	public void setUserFruits(Fruits userFruits) {
		this.userFruits = userFruits;
	}
	
}
