package cn.com.mvc.model;

import java.util.Map;

public class MapQryModel {
	private Map<String,Object> fruitMap;

	public Map<String, Object> getFruitMap() {
		return fruitMap;
	}

	public void setFruitMap(Map<String, Object> fruitMap) {
		this.fruitMap = fruitMap;
	}
	
}
