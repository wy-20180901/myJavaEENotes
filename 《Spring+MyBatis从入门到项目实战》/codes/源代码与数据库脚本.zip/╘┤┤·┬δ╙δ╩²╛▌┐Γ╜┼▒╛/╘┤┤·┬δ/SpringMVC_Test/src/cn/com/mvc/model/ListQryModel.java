package cn.com.mvc.model;

import java.util.List;

public class ListQryModel {
	private List<Fruits> fruitList;

	public List<Fruits> getFruitList() {
		return fruitList;
	}

	public void setFruitList(List<Fruits> fruitList) {
		this.fruitList = fruitList;
	}
	
}
