for ((i=1901;i<=2000;i+=1))
do
  echo s3n://hadoopbook/ncdc/raw/isd-$i.tar.bz2
done
