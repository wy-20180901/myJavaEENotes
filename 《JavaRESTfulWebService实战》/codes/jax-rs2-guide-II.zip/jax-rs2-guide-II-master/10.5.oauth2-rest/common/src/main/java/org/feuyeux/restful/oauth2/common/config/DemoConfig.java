package org.feuyeux.restful.oauth2.common.config;

/**
 * Created by erichan
 * on 16/3/11.
 */
public interface DemoConfig {
    String ROLE = "KING";
    String ROLE_TAG = "ROLE_KING";
}
