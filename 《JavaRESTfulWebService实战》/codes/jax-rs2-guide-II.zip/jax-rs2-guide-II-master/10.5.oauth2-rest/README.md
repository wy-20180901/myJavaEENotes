This demo is based from [rest-oauth2-sample](https://github.com/rcandidosilva/rest-oauth2-sample)

More reading:
- [Spring Security Reference](http://docs.spring.io/spring-security/site/docs/3.2.9.RELEASE/reference/htmlsingle/)
- [OAuth for Spring Security](https://github.com/spring-projects/spring-security-oauth) and its [Tutorial](http://projects.spring.io/spring-security-oauth/docs/tutorial.html)