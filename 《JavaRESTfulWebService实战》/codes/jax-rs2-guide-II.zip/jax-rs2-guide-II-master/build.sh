#!/usr/bin/env bash
mvn clean install -DskipTests